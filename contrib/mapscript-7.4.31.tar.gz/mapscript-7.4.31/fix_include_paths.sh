#/bin/sh
find ./src -name \*.i -exec sed -i -e 's/\([%#]include "\)\.\.\/\.\.\(\/[a-z0-9-]\+\.h"\)/\1mapserver\2/' {} \;
#find ./src -name \*.i -exec sed -i -e 's/[%#]\(include "\)\.\.\/\.\.\(\/[a-z0-9-]\+\.h"\)/#\1mapserver\2/' {} \;
