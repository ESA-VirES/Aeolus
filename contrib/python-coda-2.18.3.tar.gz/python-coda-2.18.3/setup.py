from io import open
from setuptools import setup, find_packages, Distribution, Extension
from setuptools.command.build_py import build_py
from setuptools.command.build_ext import build_ext


class custom_build_py(build_py):
    def run(self):
        # execute build_ext before build_py to grab the SWIG generated wrapper
        self.run_command("build_ext")
        build_py.run(self)


class custom_build_ext(build_ext):
    """
    Safe Numpy bootstrapping 
    see https://stackoverflow.com/questions/19919905/how-to-bootstrap-numpy-installation-in-setup-py
    """
    def finalize_options(self):
        super().finalize_options()
        # Prevent numpy from thinking it is still in its setup process:
        __builtins__.__NUMPY_SETUP__ = False
        import numpy
        self.include_dirs.append(numpy.get_include())


class BinaryDistribution(Distribution):
    """
    Distribution which always forces a binary package with platform name
    See http://lucumr.pocoo.org/2014/1/27/python-on-wheels/
    and https://stackoverflow.com/questions/24071491/how-can-i-make-a-python-wheel-from-an-existing-native-library
    """
    def has_ext_modules(foo):
        return True

    def is_pure(self):
        return False


def read_readme():
    with open('README.txt', "r", encoding="utf-8") as f:
        return f.read()


setup(
    name="python-coda",
    description = "The Common Data Access toolbox (CODA)",
    long_description=read_readme(),
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: C',
        'Topic :: Scientific/Engineering',
    ],
    license = "BSD",
    version="2.18.3",
    url="https://atmospherictoolbox.org/coda/",
    author="Martin Paces",
    author_email="martin.paces@eox.at",
    packages=find_packages(),
    package_data={},
    distclass=BinaryDistribution,
    ext_modules=[
        Extension(
            'coda._codac', ['coda/codac.i'],
            swig_opts=['-I/usr/include'],
            include_dirs=[],
            libraries = ['coda']
        ),
    ],
    cmdclass={
        'build_py': custom_build_py,
        'build_ext': custom_build_ext,
    },
    setup_requires=['numpy'],
)
