The Common Data Access toolbox (CODA) - Python bindings
=======================================================

Extracted from the `S[&]T source <https://atmospherictoolbox.org/coda/>`
and re-packaged by EOX.
